const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-GZ5LPE5W-DK8SWtHq.js","./index-CtwwKZrY.js"])))=>i.map(i=>d[i]);
import{r as a,_ as e}from"./index-CtwwKZrY.js";var _=a("TabsBar",{web:()=>e(()=>import("./web-GZ5LPE5W-DK8SWtHq.js"),__vite__mapDeps([0,1]),import.meta.url).then(r=>new r.TabsBarWeb)});export{_ as TabsBar};
