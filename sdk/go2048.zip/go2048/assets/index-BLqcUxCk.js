const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-D3dlPCHJ.js","./index-CtwwKZrY.js"])))=>i.map(i=>d[i]);
import{r,_ as t}from"./index-CtwwKZrY.js";const _=r("SplashScreen",{web:()=>t(()=>import("./web-D3dlPCHJ.js"),__vite__mapDeps([0,1]),import.meta.url).then(e=>new e.SplashScreenWeb)});export{_ as SplashScreen};
