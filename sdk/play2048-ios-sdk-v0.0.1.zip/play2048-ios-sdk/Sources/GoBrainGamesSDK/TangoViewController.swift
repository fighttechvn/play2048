import UIKit

/// Tango — fill a 6×6 grid with suns/moons: 3 of each per row & column, never 3
/// of the same in a row. Tap cycles empty → sun → moon.
final class TangoViewController: BaseGameViewController {
    private let n = 6
    private var board = [Int]()     // 0 empty, 1 sun, 2 moon
    private var given = [Bool]()
    private var solved = false
    private let grid = CellGridView()
    private let info = UILabel()
    private let sun = UIColor(red: 0.98, green: 0.75, blue: 0.18, alpha: 1)
    private let moon = UIColor(red: 0.45, green: 0.55, blue: 0.95, alpha: 1)

    override func viewDidLoad() {
        super.viewDidLoad()
        grid.cols = n; grid.rows = n; grid.corner = 8
        grid.cellFill = { [weak self] r, c in
            guard let self = self else { return .clear }
            return self.given[r*self.n+c] ? UIColor.white.withAlphaComponent(0.12) : UIColor.white.withAlphaComponent(0.05)
        }
        grid.overlay = { [weak self] ctx, rect, r, c in
            guard let self = self else { return }
            let v = self.board[r*self.n+c]; guard v != 0 else { return }
            (v == 1 ? self.sun : self.moon).setFill()
            let d = rect.insetBy(dx: rect.width*0.22, dy: rect.height*0.22)
            ctx.fillEllipse(in: d)
        }
        grid.onTap = { [weak self] r, c in self?.tap(r, c) }
        let t = gameTitleLabel("Tango")
        let i = infoLabel(); i.text = isVI ? "3 ☀ và 3 🌙 mỗi hàng/cột, không 3 liền nhau" : "3 ☀ & 3 🌙 per row/col, never 3 in a row"
        info.text = ""
        layoutPuzzle(title: t, grid: grid, info: i, buttons: [makeButton(isVI ? "Ván mới" : "New", filled: false) { [weak self] in self?.newGame() }])
        infoRef = i
        newGame()
    }
    private var infoRef: UILabel?

    private func newGame() {
        solved = false
        let sol = Self.generate(n)
        board = sol; given = [Bool](repeating: true, count: n*n)
        var holes = n*n*2/3
        for i in Array(0..<n*n).shuffled() where holes > 0 { given[i] = false; board[i] = 0; holes -= 1 }
        grid.setNeedsDisplay(); emit("game_start")
    }
    private func tap(_ r: Int, _ c: Int) {
        let i = r*n+c; guard !solved, !given[i] else { return }
        board[i] = (board[i] + 1) % 3; grid.setNeedsDisplay()
        if board.allSatisfy({ $0 != 0 }) && valid() {
            solved = true; infoRef?.text = isVI ? "✓ Đúng!" : "✓ Solved!"; emit("level_complete", ["win": true])
        }
    }
    private func valid() -> Bool {
        for r in 0..<n {
            var s = 0, m = 0
            for c in 0..<n {
                let v = board[r*n+c]; if v == 1 { s += 1 } else if v == 2 { m += 1 }
                if c >= 2 && v != 0 && board[r*n+c-1] == v && board[r*n+c-2] == v { return false }
            }
            if s != n/2 || m != n/2 { return false }
        }
        for c in 0..<n {
            var s = 0, m = 0
            for r in 0..<n {
                let v = board[r*n+c]; if v == 1 { s += 1 } else if v == 2 { m += 1 }
                if r >= 2 && v != 0 && board[(r-1)*n+c] == v && board[(r-2)*n+c] == v { return false }
            }
            if s != n/2 || m != n/2 { return false }
        }
        return true
    }

    private static func generate(_ n: Int) -> [Int] {
        var b = [Int](repeating: 0, count: n*n)
        func ok(_ i: Int, _ v: Int) -> Bool {
            let r = i/n, c = i%n
            if c >= 2 && b[i-1] == v && b[i-2] == v { return false }
            if r >= 2 && b[i-n] == v && b[i-2*n] == v { return false }
            var rc = 0; for cc in 0..<n where b[r*n+cc] == v { rc += 1 }; if rc >= n/2 { return false }
            var cc2 = 0; for rr in 0..<n where b[rr*n+c] == v { cc2 += 1 }; if cc2 >= n/2 { return false }
            return true
        }
        func solve(_ i: Int) -> Bool {
            if i == n*n { return true }
            for v in [1, 2].shuffled() where ok(i, v) { b[i] = v; if solve(i+1) { return true }; b[i] = 0 }
            return false
        }
        _ = solve(0)
        return b
    }
}
