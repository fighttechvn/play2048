import UIKit

/// Sudoku — runtime-generated 9×9, tap a cell + number pad, win when complete.
final class SudokuViewController: BaseGameViewController {
    private var solution = [Int](repeating: 0, count: 81)
    private var given = [Bool](repeating: false, count: 81)
    private var cur = [Int](repeating: 0, count: 81)
    private var sel = -1
    private var solved = false

    private let grid = CellGridView()
    private let info = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        grid.cols = 9; grid.rows = 9; grid.boxSize = 3; grid.gap = 1; grid.corner = 2
        grid.cellFill = { [weak self] r, c in self?.fill(r*9+c) ?? .clear }
        grid.cellText = { [weak self] r, c in self?.text(r*9+c) }
        grid.onTap = { [weak self] r, c in self?.selectCell(r*9+c) }
        buildLayout()
        newGame()
    }

    private func buildLayout() {
        let title = gameTitleLabel("Sudoku")
        info.textColor = UIColor.white.withAlphaComponent(0.7); info.font = .systemFont(ofSize: 15, weight: .semibold); info.textAlignment = .center

        // number pad 1–9 + erase
        let pad = UIStackView(); pad.axis = .horizontal; pad.distribution = .fillEqually; pad.spacing = 6
        for v in 1...9 { pad.addArrangedSubview(padButton("\(v)") { [weak self] in self?.enter(v) }) }
        let pad2 = UIStackView(arrangedSubviews: [padButton(isVI ? "Xoá" : "Erase") { [weak self] in self?.enter(0) },
                                                  makeButton(isVI ? "Ván mới" : "New", filled: false) { [weak self] in self?.newGame() }])
        pad2.axis = .horizontal; pad2.spacing = 12; pad2.distribution = .fillEqually

        [title, grid, info, pad, pad2].forEach { $0.translatesAutoresizingMaskIntoConstraints = false; view.addSubview($0) }
        let g = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            title.topAnchor.constraint(equalTo: g.topAnchor, constant: 14),
            title.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 20),
            grid.topAnchor.constraint(equalTo: title.bottomAnchor, constant: 16),
            grid.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            grid.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 16),
            grid.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -16),
            grid.heightAnchor.constraint(equalTo: grid.widthAnchor),
            info.topAnchor.constraint(equalTo: grid.bottomAnchor, constant: 12),
            info.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            pad.topAnchor.constraint(equalTo: info.bottomAnchor, constant: 12),
            pad.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 16),
            pad.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -16),
            pad.heightAnchor.constraint(equalToConstant: 44),
            pad2.topAnchor.constraint(equalTo: pad.bottomAnchor, constant: 10),
            pad2.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 40),
            pad2.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -40),
            pad2.heightAnchor.constraint(equalToConstant: 48),
        ])
    }
    private func padButton(_ t: String, _ a: @escaping () -> Void) -> UIButton {
        let b = ClosureButton(type: .system)
        b.setTitle(t, for: .normal); b.setTitleColor(.white, for: .normal)
        b.titleLabel?.font = .systemFont(ofSize: 18, weight: .semibold)
        b.backgroundColor = UIColor.white.withAlphaComponent(0.10); b.layer.cornerRadius = 8
        b.onTap = a; b.addTarget(b, action: #selector(ClosureButton.fire), for: .touchUpInside)
        return b
    }

    // MARK: - State / render
    private func fill(_ i: Int) -> UIColor {
        if i == sel { return accent.withAlphaComponent(0.40) }
        let r = i/9, c = i%9
        if sel >= 0, (sel/9 == r || sel%9 == c || (sel/9/3 == r/3 && sel%9/3 == c/3)) { return UIColor.white.withAlphaComponent(0.10) }
        return UIColor.white.withAlphaComponent(0.05)
    }
    private func text(_ i: Int) -> (String, UIColor)? {
        let v = given[i] ? solution[i] : cur[i]
        if v == 0 { return nil }
        let bad = !given[i] && cur[i] != 0 && cur[i] != solution[i]
        return ("\(v)", given[i] ? .white : (bad ? UIColor(red: 1, green: 0.4, blue: 0.45, alpha: 1) : accent))
    }
    private func selectCell(_ i: Int) { guard !solved, !given[i] else { sel = given[i] ? -1 : sel; return }; sel = i; grid.setNeedsDisplay() }
    private func enter(_ v: Int) {
        guard !solved, sel >= 0, !given[sel] else { return }
        cur[sel] = v; grid.setNeedsDisplay()
        if isComplete() { solved = true; sel = -1; info.text = isVI ? "✓ Hoàn thành!" : "✓ Solved!"; grid.setNeedsDisplay(); emit("level_complete", ["win": true]) }
    }
    private func isComplete() -> Bool { for i in 0..<81 where (given[i] ? solution[i] : cur[i]) != solution[i] { return false }; return true }

    // MARK: - Generation
    private func newGame() {
        solved = false; sel = -1; info.text = ""
        solution = Self.generate()
        cur = [Int](repeating: 0, count: 81)
        given = [Bool](repeating: true, count: 81)
        var holes = 46                          // remove cells
        for i in Array(0..<81).shuffled() where holes > 0 { given[i] = false; holes -= 1 }
        grid.setNeedsDisplay(); emit("game_start")
    }

    private static func generate() -> [Int] {
        var b = [Int](repeating: 0, count: 81)
        func ok(_ i: Int, _ v: Int) -> Bool {
            let r = i/9, c = i%9
            for k in 0..<9 { if b[r*9+k] == v || b[k*9+c] == v { return false } }
            let br = r/3*3, bc = c/3*3
            for dr in 0..<3 { for dc in 0..<3 { if b[(br+dr)*9+bc+dc] == v { return false } } }
            return true
        }
        func solve(_ i: Int) -> Bool {
            if i == 81 { return true }
            if b[i] != 0 { return solve(i+1) }
            for v in Array(1...9).shuffled() where ok(i, v) { b[i] = v; if solve(i+1) { return true }; b[i] = 0 }
            return false
        }
        _ = solve(0)
        return b
    }
}
