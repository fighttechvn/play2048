//  GoBrainGames.swift
//  GoBrainGamesSDK — native Swift mini-games (no WebView), one shared package.
//
//    let games = GoBrainGamesCoordinator()
//    games.onEvent = { print($0.name, $0.gameId, $0.score ?? -1) }
//    games.present(.go2048, from: self)
//
//  Catalog: go2048, zip, patch, tango, wend, sudoku, mend. Each opens a native
//  UIViewController. Games not yet ported show a "coming soon" screen
//  (`isAvailable == false`) so the host UI/integration is complete today and new
//  native games drop in without API changes.

import UIKit

public struct GoBrainGameConfig {
    public var locale: String
    public init(locale: String = "en") { self.locale = locale }
}

/// A gameplay event forwarded to the host app.
public struct GoBrainGameEvent {
    public let name: String          // "game_start" | "game_over" | "level_complete" | …
    public let gameId: String        // "go2048", "sudoku", …
    public let params: [String: Any]
    public init(name: String, gameId: String, params: [String: Any] = [:]) {
        self.name = name; self.gameId = gameId; self.params = params
    }
    public var score: Int? { params["score"] as? Int }
    public var level: Int? { params["level"] as? Int }
    public var win: Bool? { params["win"] as? Bool }
}

public protocol GoBrainGamesDelegate: AnyObject {
    func goBrainGames(_ c: GoBrainGamesCoordinator, didEmit event: GoBrainGameEvent)
    func goBrainGamesDidClose(_ c: GoBrainGamesCoordinator)
}
public extension GoBrainGamesDelegate { func goBrainGamesDidClose(_ c: GoBrainGamesCoordinator) {} }

/// The game catalog.
public enum GoBrainGame: String, CaseIterable {
    case go2048, zip, patch, tango, wend, sudoku, mend

    public var title: String {
        switch self {
        case .go2048: return "2048"
        case .zip: return "Zip"
        case .patch: return "Patch"
        case .tango: return "Tango"
        case .wend: return "Wend"
        case .sudoku: return "Sudoku"
        case .mend: return "Mend"
        }
    }
    public var tagline: String {
        switch self {
        case .go2048: return "Merge tiles to 2048"
        case .zip: return "Draw one path through every cell"
        case .patch: return "Split the grid into shapes"
        case .tango: return "Balance suns and moons"
        case .wend: return "Trace hidden words"
        case .sudoku: return "Classic 9×9 logic"
        case .mend: return "Mirror the pattern back"
        }
    }
    /// True once the game is implemented natively (others show a placeholder).
    public var isAvailable: Bool {
        switch self {
        case .go2048, .mend, .sudoku, .tango, .patch, .zip, .wend: return true
        }
    }
}

public final class GoBrainGamesCoordinator {
    public let config: GoBrainGameConfig
    public weak var delegate: GoBrainGamesDelegate?
    public var onEvent: ((GoBrainGameEvent) -> Void)?
    public var onClose: (() -> Void)?

    public init(config: GoBrainGameConfig = GoBrainGameConfig()) { self.config = config }

    public func makeViewController(for game: GoBrainGame) -> UIViewController {
        let vc: BaseGameViewController
        switch game {
        case .go2048: vc = Game2048ViewController()
        case .mend:   vc = MendViewController()
        case .sudoku: vc = SudokuViewController()
        case .tango:  vc = TangoViewController()
        case .patch:  vc = PatchViewController()
        case .zip:    vc = ZipViewController()
        case .wend:   vc = WendViewController()
        }
        vc.gameId = game.rawValue
        vc.locale = config.locale
        vc.onGameEvent = { [weak self] name, params in
            guard let self = self else { return }
            let e = GoBrainGameEvent(name: name, gameId: game.rawValue, params: params)
            self.onEvent?(e); self.delegate?.goBrainGames(self, didEmit: e)
        }
        vc.onClosed = { [weak self] in
            guard let self = self else { return }
            self.onClose?(); self.delegate?.goBrainGamesDidClose(self)
        }
        return vc
    }

    @discardableResult
    public func present(_ game: GoBrainGame, from presenter: UIViewController, animated: Bool = true) -> UIViewController {
        let vc = makeViewController(for: game)
        vc.modalPresentationStyle = .fullScreen
        presenter.present(vc, animated: animated)
        return vc
    }
}
