import UIKit

/// Patch (Shikaku) — drag to split the grid into rectangles; each rectangle must
/// contain exactly one number equal to its area. Tap a rectangle to clear it.
final class PatchViewController: BaseGameViewController {
    private let n = 6
    private var clue = [Int: Int]()         // cell idx → area number
    private var regionOf = [Int]()          // cell idx → region id (-1 none)
    private var nextRegion = 0
    private var solved = false
    private var startCell: (Int, Int)?
    private var curCell: (Int, Int)?
    private let grid = CellGridView()
    private let info = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        grid.cols = n; grid.rows = n; grid.corner = 6; grid.gap = 2
        grid.cellFill = { [weak self] r, c in self?.fill(r, c) ?? .clear }
        grid.cellText = { [weak self] r, c in
            guard let self = self, let a = self.clue[r*self.n+c] else { return nil }
            return ("\(a)", .white)
        }
        grid.gridOverlay = { [weak self] ctx, frame, cell in self?.drawPreview(ctx, frame, cell) }
        grid.onDrag = { [weak self] r, c in self?.drag(r, c) }
        grid.onDragEnd = { [weak self] in self?.dragEnd() }
        let t = gameTitleLabel("Patch")
        let i = infoLabel(); i.text = isVI ? "Kéo tạo hình chữ nhật = số ô của nó" : "Drag rectangles whose area equals their number"
        info.text = ""
        layoutPuzzle(title: t, grid: grid, info: i, buttons: [makeButton(isVI ? "Ván mới" : "New", filled: false) { [weak self] in self?.newGame() }])
        infoRef = i
        newGame()
    }
    private var infoRef: UILabel?

    private func newGame() {
        solved = false; clue.removeAll(); regionOf = [Int](repeating: -1, count: n*n); nextRegion = 0
        var rects: [(Int, Int, Int, Int)] = []
        partition(0, 0, n, n, &rects)
        for (x, y, w, h) in rects {
            let cells = (0..<h).flatMap { dy in (0..<w).map { dx in (y+dy)*n + (x+dx) } }
            clue[cells.randomElement()!] = w*h
        }
        grid.setNeedsDisplay(); emit("game_start")
    }
    private func partition(_ x: Int, _ y: Int, _ w: Int, _ h: Int, _ out: inout [(Int, Int, Int, Int)]) {
        let area = w*h
        if area <= 1 { out.append((x, y, w, h)); return }
        if area <= 6 && (area <= 3 || Bool.random()) { out.append((x, y, w, h)); return }
        if w >= h && w > 1 { let cut = Int.random(in: 1..<w); partition(x, y, cut, h, &out); partition(x+cut, y, w-cut, h, &out) }
        else if h > 1 { let cut = Int.random(in: 1..<h); partition(x, y, w, cut, &out); partition(x, y+cut, w, h-cut, &out) }
        else { out.append((x, y, w, h)) }
    }

    private func fill(_ r: Int, _ c: Int) -> UIColor {
        let reg = regionOf[r*n+c]
        if reg >= 0 { return Self.palette[reg % Self.palette.count] }
        return UIColor.white.withAlphaComponent(0.05)
    }
    static let palette: [UIColor] = [
        UIColor(red: 0.49, green: 0.36, blue: 1, alpha: 0.5), UIColor(red: 0.18, green: 0.83, blue: 0.75, alpha: 0.5),
        UIColor(red: 0.99, green: 0.55, blue: 0.39, alpha: 0.5), UIColor(red: 0.64, green: 0.9, blue: 0.21, alpha: 0.5),
        UIColor(red: 0.98, green: 0.75, blue: 0.14, alpha: 0.5), UIColor(red: 0.75, green: 0.52, blue: 0.99, alpha: 0.5),
        UIColor(red: 0.3, green: 0.7, blue: 1, alpha: 0.5), UIColor(red: 1, green: 0.45, blue: 0.6, alpha: 0.5),
    ]

    private func drag(_ r: Int, _ c: Int) {
        if startCell == nil { startCell = (r, c) }
        curCell = (r, c); grid.setNeedsDisplay()
    }
    private func dragEnd() {
        defer { startCell = nil; curCell = nil; grid.setNeedsDisplay() }
        guard let s = startCell, let e = curCell else { return }
        let r0 = min(s.0, e.0), r1 = max(s.0, e.0), c0 = min(s.1, e.1), c1 = max(s.1, e.1)
        let cells = (r0...r1).flatMap { r in (c0...c1).map { c in r*n+c } }
        // single tap on a region → clear it
        if cells.count == 1, regionOf[cells[0]] >= 0 {
            let id = regionOf[cells[0]]; for i in 0..<n*n where regionOf[i] == id { regionOf[i] = -1 }
            return
        }
        // commit only if all cells free + exactly one clue + area matches
        guard cells.allSatisfy({ regionOf[$0] == -1 }) else { return }
        let clues = cells.filter { clue[$0] != nil }
        guard clues.count == 1, clue[clues[0]] == cells.count else { return }
        let id = nextRegion; nextRegion += 1
        for i in cells { regionOf[i] = id }
        if regionOf.allSatisfy({ $0 >= 0 }) { solved = true; infoRef?.text = isVI ? "✓ Xong!" : "✓ Solved!"; emit("level_complete", ["win": true]) }
    }

    private func drawPreview(_ ctx: CGContext, _ frame: CGRect, _ cell: CGFloat) {
        guard let s = startCell, let e = curCell else { return }
        let r0 = min(s.0, e.0), r1 = max(s.0, e.0), c0 = min(s.1, e.1), c1 = max(s.1, e.1)
        let rect = CGRect(x: frame.minX + CGFloat(c0)*cell, y: frame.minY + CGFloat(r0)*cell,
                          width: CGFloat(c1-c0+1)*cell, height: CGFloat(r1-r0+1)*cell).insetBy(dx: 2, dy: 2)
        ctx.setStrokeColor(accent.cgColor); ctx.setLineWidth(3)
        UIBezierPath(roundedRect: rect, cornerRadius: 6).stroke()
    }
}
