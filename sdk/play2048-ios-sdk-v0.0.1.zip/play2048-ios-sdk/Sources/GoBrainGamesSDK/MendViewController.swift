import UIKit

/// Mend — make the editable right half mirror the locked left half.
final class MendViewController: BaseGameViewController {
    private let n = 6                       // size (even)
    private var left = [[Bool]]()           // locked given (full grid width, left half meaningful)
    private var right = [[Bool]]()          // editable right half values, indexed [r][c-half]
    private var solved = false
    private let grid = CellGridView()
    private let info = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        grid.cols = n; grid.rows = n; grid.corner = 8
        grid.cellFill = { [weak self] r, c in self?.fill(r, c) ?? .clear }
        grid.gridOverlay = { [weak self] ctx, frame, cell in
            guard self != nil else { return }
            ctx.setStrokeColor(UIColor.white.withAlphaComponent(0.25).cgColor); ctx.setLineWidth(2)
            let x = frame.minX + frame.width/2
            ctx.move(to: CGPoint(x: x, y: frame.minY)); ctx.addLine(to: CGPoint(x: x, y: frame.maxY)); ctx.strokePath()
        }
        grid.onTap = { [weak self] r, c in self?.tap(r, c) }
        let t = gameTitleLabel("Mend")
        let i = infoLabel(); i.text = isVI ? "Soi gương nửa trái sang phải" : "Mirror the left side onto the right"
        info.isHidden = true
        layoutPuzzle(title: t, grid: grid, info: i, buttons: [makeButton(isVI ? "Ván mới" : "New", filled: false) { [weak self] in self?.newGame() }])
        self.infoRef = i
        newGame()
    }
    private var infoRef: UILabel?

    private func newGame() {
        solved = false
        left = (0..<n).map { _ in (0..<n).map { _ in Bool.random() } }
        // right starts wrong: a few cells flipped from the mirror target
        right = (0..<n).map { r in (0..<(n/2)).map { hc in left[r][n - 1 - (n/2 + hc)] } }
        var flips = 5
        while flips > 0 { let r = Int.random(in: 0..<n), hc = Int.random(in: 0..<(n/2)); right[r][hc].toggle(); flips -= 1 }
        if isSolved() { right[0][0].toggle() }   // ensure not already done
        grid.setNeedsDisplay()
        emit("game_start")
    }

    private func target(_ r: Int, _ c: Int) -> Bool { left[r][n - 1 - c] }   // for right col c
    private func fill(_ r: Int, _ c: Int) -> UIColor {
        let half = n/2
        if c < half {                                  // locked left
            return left[r][c] ? accent.withAlphaComponent(0.85) : UIColor.white.withAlphaComponent(0.05)
        }
        let on = right[r][c - half]
        return on ? accent : UIColor.white.withAlphaComponent(0.08)
    }
    private func tap(_ r: Int, _ c: Int) {
        guard !solved, c >= n/2 else { return }
        right[r][c - n/2].toggle(); grid.setNeedsDisplay()
        if isSolved() { solved = true; infoRef?.isHidden = false; infoRef?.text = isVI ? "✓ Cân đối!" : "✓ Symmetric!"; emit("level_complete", ["win": true]) }
    }
    private func isSolved() -> Bool {
        for r in 0..<n { for hc in 0..<(n/2) where right[r][hc] != target(r, n/2 + hc) { return false } }
        return true
    }
}
