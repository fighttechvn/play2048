import UIKit

/// Shared base for every native game screen: dark background + a close button,
/// plus event/close hooks the coordinator wires up.
class BaseGameViewController: UIViewController {
    var gameId = ""
    var locale = "en"
    var onGameEvent: ((String, [String: Any]) -> Void)?
    var onClosed: (() -> Void)?

    let bg = UIColor(red: 14/255, green: 17/255, blue: 22/255, alpha: 1)
    let accent = UIColor(red: 124/255, green: 92/255, blue: 255/255, alpha: 1)
    var isVI: Bool { locale.hasPrefix("vi") }

    override var prefersStatusBarHidden: Bool { true }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = bg
        addCloseButton()
    }

    func emit(_ name: String, _ params: [String: Any] = [:]) { onGameEvent?(name, params) }

    private func addCloseButton() {
        let b = UIButton(type: .system)
        b.setTitle("✕", for: .normal); b.setTitleColor(.white, for: .normal)
        b.titleLabel?.font = .systemFont(ofSize: 20, weight: .semibold)
        b.backgroundColor = UIColor.black.withAlphaComponent(0.35); b.layer.cornerRadius = 18
        b.translatesAutoresizingMaskIntoConstraints = false
        b.addTarget(self, action: #selector(closeTapped), for: .touchUpInside)
        view.addSubview(b)
        let g = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            b.widthAnchor.constraint(equalToConstant: 36), b.heightAnchor.constraint(equalToConstant: 36),
            b.topAnchor.constraint(equalTo: g.topAnchor, constant: 8),
            b.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -12),
        ])
        view.bringSubviewToFront(b)
    }
    @objc private func closeTapped() { dismiss(animated: true) { [weak self] in self?.onClosed?() } }

    func makeButton(_ title: String, filled: Bool, _ action: @escaping () -> Void) -> UIButton {
        let b = ClosureButton(type: .system)
        b.setTitle(title, for: .normal)
        b.titleLabel?.font = .systemFont(ofSize: 17, weight: .semibold)
        b.layer.cornerRadius = 14; b.layer.masksToBounds = true
        b.backgroundColor = filled ? accent : UIColor.white.withAlphaComponent(0.10)
        b.setTitleColor(.white, for: .normal)
        b.translatesAutoresizingMaskIntoConstraints = false
        b.heightAnchor.constraint(equalToConstant: 52).isActive = true
        b.widthAnchor.constraint(equalToConstant: 240).isActive = true
        b.onTap = action
        b.addTarget(b, action: #selector(ClosureButton.fire), for: .touchUpInside)
        return b
    }
}

final class ClosureButton: UIButton { var onTap: (() -> Void)?; @objc func fire() { onTap?() } }

/// Shown for games not yet ported to native Swift.
final class PlaceholderGameViewController: BaseGameViewController {
    private let game: GoBrainGame
    init(game: GoBrainGame) { self.game = game; super.init(nibName: nil, bundle: nil) }
    required init?(coder: NSCoder) { fatalError() }

    override func viewDidLoad() {
        super.viewDidLoad()
        let title = UILabel()
        title.text = game.title; title.font = .systemFont(ofSize: 36, weight: .heavy)
        title.textColor = .white; title.textAlignment = .center
        let sub = UILabel()
        sub.text = isVI ? "Đang phát triển (native)" : "Coming soon (native)"
        sub.textColor = UIColor.white.withAlphaComponent(0.6); sub.textAlignment = .center
        sub.numberOfLines = 0
        let stack = UIStackView(arrangedSubviews: [title, sub])
        stack.axis = .vertical; stack.spacing = 10; stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            stack.leadingAnchor.constraint(greaterThanOrEqualTo: view.leadingAnchor, constant: 24),
            stack.trailingAnchor.constraint(lessThanOrEqualTo: view.trailingAnchor, constant: -24),
        ])
        emit("game_open", ["available": false])
    }
}
