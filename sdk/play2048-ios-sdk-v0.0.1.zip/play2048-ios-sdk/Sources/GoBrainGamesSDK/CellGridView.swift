import UIKit

/// Generic CoreGraphics grid used by the puzzle games. Square cells, optional
/// thick box lines (Sudoku), per-cell fill + text, and tap / drag callbacks.
final class CellGridView: UIView {
    var cols = 4 { didSet { setNeedsDisplay() } }
    var rows = 4 { didSet { setNeedsDisplay() } }
    var boxSize = 0                       // >0 → thick line every N cells
    var gap: CGFloat = 4
    var corner: CGFloat = 6

    var cellFill: ((Int, Int) -> UIColor)?            // (row,col) → fill
    var cellText: ((Int, Int) -> (String, UIColor)?)? // (row,col) → (text,color)
    var overlay: ((CGContext, CGRect, Int, Int) -> Void)?  // custom per-cell draw
    var gridOverlay: ((CGContext, CGRect, CGFloat) -> Void)? // draw on top (paths)

    var onTap: ((Int, Int) -> Void)?
    var onDrag: ((Int, Int) -> Void)?
    var onDragEnd: (() -> Void)?

    private(set) var cell: CGFloat = 0
    private(set) var ox: CGFloat = 0
    private(set) var oy: CGFloat = 0

    override init(frame: CGRect) { super.init(frame: frame); backgroundColor = .clear; isOpaque = false; contentMode = .redraw; isMultipleTouchEnabled = false }
    required init?(coder: NSCoder) { fatalError() }

    private func layoutMetrics() {
        cell = min((bounds.width) / CGFloat(cols), (bounds.height) / CGFloat(rows))
        ox = (bounds.width - cell * CGFloat(cols)) / 2
        oy = (bounds.height - cell * CGFloat(rows)) / 2
    }

    func rect(_ r: Int, _ c: Int) -> CGRect {
        CGRect(x: ox + CGFloat(c) * cell + gap/2, y: oy + CGFloat(r) * cell + gap/2, width: cell - gap, height: cell - gap)
    }
    func cellAt(_ p: CGPoint) -> (Int, Int)? {
        let c = Int((p.x - ox) / cell), r = Int((p.y - oy) / cell)
        guard r >= 0, r < rows, c >= 0, c < cols else { return nil }
        return (r, c)
    }

    override func draw(_ rect: CGRect) {
        guard let ctx = UIGraphicsGetCurrentContext() else { return }
        layoutMetrics()
        for r in 0..<rows { for c in 0..<cols {
            let cr = self.rect(r, c)
            let path = UIBezierPath(roundedRect: cr, cornerRadius: corner)
            (cellFill?(r, c) ?? UIColor.white.withAlphaComponent(0.06)).setFill(); path.fill()
            overlay?(ctx, cr, r, c)
            if let (s, color) = cellText?(r, c), !s.isEmpty {
                let attrs: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: cell * 0.42, weight: .bold), .foregroundColor: color]
                let ns = s as NSString; let sz = ns.size(withAttributes: attrs)
                ns.draw(at: CGPoint(x: cr.midX - sz.width/2, y: cr.midY - sz.height/2), withAttributes: attrs)
            }
        } }
        if boxSize > 0 {
            ctx.setStrokeColor(UIColor.white.withAlphaComponent(0.5).cgColor); ctx.setLineWidth(2)
            var i = 0
            while i <= cols {
                if i % boxSize == 0 {
                    let x = ox + CGFloat(i) * cell
                    ctx.move(to: CGPoint(x: x, y: oy)); ctx.addLine(to: CGPoint(x: x, y: oy + cell * CGFloat(rows)))
                    let y = oy + CGFloat(i) * cell
                    if i <= rows { ctx.move(to: CGPoint(x: ox, y: y)); ctx.addLine(to: CGPoint(x: ox + cell * CGFloat(cols), y: y)) }
                }
                i += 1
            }
            ctx.strokePath()
        }
        if let go = gridOverlay { go(ctx, CGRect(x: ox, y: oy, width: cell * CGFloat(cols), height: cell * CGFloat(rows)), cell) }
    }

    override func touchesBegan(_ t: Set<UITouch>, with e: UIEvent?) { if let p = t.first?.location(in: self), let (r, c) = cellAt(p) { onTap?(r, c); onDrag?(r, c) } }
    override func touchesMoved(_ t: Set<UITouch>, with e: UIEvent?) { if let p = t.first?.location(in: self), let (r, c) = cellAt(p) { onDrag?(r, c) } }
    override func touchesEnded(_ t: Set<UITouch>, with e: UIEvent?) { onDragEnd?() }
    override func touchesCancelled(_ t: Set<UITouch>, with e: UIEvent?) { onDragEnd?() }
}

/// Small shared helpers for the puzzle game screens.
extension BaseGameViewController {
    func gameTitleLabel(_ s: String) -> UILabel {
        let l = UILabel(); l.text = s; l.font = .systemFont(ofSize: 30, weight: .heavy); l.textColor = .white; return l
    }
    func infoLabel() -> UILabel {
        let l = UILabel(); l.textColor = UIColor.white.withAlphaComponent(0.7); l.font = .systemFont(ofSize: 15, weight: .semibold)
        l.textAlignment = .center; l.numberOfLines = 0; return l
    }
    /// Standard layout: title (top-left), a square grid (center), info + a button row (bottom).
    func layoutPuzzle(title: UILabel, grid: UIView, info: UILabel, buttons: [UIButton]) {
        let g = view.safeAreaLayoutGuide
        [title, grid, info].forEach { $0.translatesAutoresizingMaskIntoConstraints = false; view.addSubview($0) }
        let row = UIStackView(arrangedSubviews: buttons); row.axis = .horizontal; row.spacing = 12; row.distribution = .fillEqually
        row.translatesAutoresizingMaskIntoConstraints = false; view.addSubview(row)
        NSLayoutConstraint.activate([
            title.topAnchor.constraint(equalTo: g.topAnchor, constant: 14),
            title.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 20),
            grid.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            grid.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -10),
            grid.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 20),
            grid.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -20),
            grid.heightAnchor.constraint(equalTo: grid.widthAnchor),
            info.topAnchor.constraint(equalTo: grid.bottomAnchor, constant: 14),
            info.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            info.leadingAnchor.constraint(greaterThanOrEqualTo: g.leadingAnchor, constant: 20),
            info.trailingAnchor.constraint(lessThanOrEqualTo: g.trailingAnchor, constant: -20),
            row.topAnchor.constraint(equalTo: info.bottomAnchor, constant: 14),
            row.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            row.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 40),
            row.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -40),
        ])
    }
}
