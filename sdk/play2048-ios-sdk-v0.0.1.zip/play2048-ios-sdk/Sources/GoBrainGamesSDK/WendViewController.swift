import UIKit

/// Wend — trace the hidden words. Each row is a word; drag across a row to find
/// it. Find all rows (every tile used once) to win.
final class WendViewController: BaseGameViewController {
    private let sets: [[String]] = [
        ["BEAT", "GAME", "PLAY", "WORD"],
        ["MIND", "FAST", "LEAP", "GLOW"],
        ["CODE", "MOVE", "STAR", "WAVE"],
        ["JUMP", "FLOW", "RISE", "BOLD"],
    ]
    private var words = [String]()
    private var grid2 = [[Character]]()
    private var found = Set<Int>()          // row indices found
    private var path = [(Int, Int)]()       // current drag path
    private var rows = 4, cols = 4
    private let grid = CellGridView()
    private let info = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        grid.corner = 8
        grid.cellFill = { [weak self] r, c in
            guard let self = self else { return .clear }
            if self.found.contains(r) { return self.accent.withAlphaComponent(0.85) }
            if self.path.contains(where: { $0 == (r, c) }) { return self.accent.withAlphaComponent(0.45) }
            return UIColor.white.withAlphaComponent(0.07)
        }
        grid.cellText = { [weak self] r, c in
            guard let self = self, r < self.rows, c < self.cols else { return nil }
            return (String(self.grid2[r][c]), .white)
        }
        grid.onDrag = { [weak self] r, c in self?.drag(r, c) }
        grid.onDragEnd = { [weak self] in self?.dragEnd() }
        let t = gameTitleLabel("Wend")
        let i = infoLabel(); i.text = isVI ? "Kéo theo hàng để tìm từ" : "Drag across a row to find each word"
        info.text = ""
        layoutPuzzle(title: t, grid: grid, info: i, buttons: [makeButton(isVI ? "Ván mới" : "New", filled: false) { [weak self] in self?.newGame() }])
        infoRef = i
        newGame()
    }
    private var infoRef: UILabel?

    private func newGame() {
        words = sets.randomElement()!
        rows = words.count; cols = words[0].count
        grid2 = words.map { Array($0) }
        found.removeAll(); path.removeAll()
        grid.rows = rows; grid.cols = cols; grid.setNeedsDisplay()
        infoRef?.text = isVI ? "Kéo theo hàng để tìm từ" : "Drag across a row to find each word"
        emit("game_start")
    }

    private func drag(_ r: Int, _ c: Int) {
        if let last = path.last { if last == (r, c) { return }
            // only extend to an adjacent cell in the same row
            if r != last.0 || abs(c - last.1) != 1 { return }
        }
        if path.contains(where: { $0 == (r, c) }) { return }
        path.append((r, c)); grid.setNeedsDisplay()
    }
    private func dragEnd() {
        defer { path.removeAll(); grid.setNeedsDisplay() }
        guard path.count >= 2 else { return }
        let r = path[0].0
        guard path.allSatisfy({ $0.0 == r }) else { return }
        let s = String(path.map { grid2[$0.0][$0.1] })
        let word = words[r]
        if (s == word || String(s.reversed()) == word), !found.contains(r) {
            found.insert(r)
            if found.count == rows { infoRef?.text = isVI ? "✓ Tìm hết!" : "✓ All found!"; emit("level_complete", ["win": true]) }
        }
    }
}
