import UIKit

/// Native 2048 — 4×4 board, swipe to merge, spawn, score, win (2048) / game over.
final class Game2048ViewController: BaseGameViewController {

    private var board = [[Int]](repeating: [Int](repeating: 0, count: 4), count: 4)
    private var score = 0 { didSet { scoreLabel.text = "\(score)" } }
    private var best = 0
    private var won = false
    private var over = false

    private let boardView = Board2048View()
    private let scoreLabel = UILabel()
    private let bestLabel = UILabel()
    private let statusLabel = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        best = UserDefaults.standard.integer(forKey: "go2048.best")
        buildUI()
        for dir: UISwipeGestureRecognizer.Direction in [.left, .right, .up, .down] {
            let g = UISwipeGestureRecognizer(target: self, action: #selector(swiped(_:)))
            g.direction = dir; boardView.addGestureRecognizer(g)
        }
        newGame()
    }

    private func buildUI() {
        let title = UILabel()
        title.text = "2048"; title.font = .systemFont(ofSize: 34, weight: .heavy)
        title.textColor = .white

        func chip(_ caption: String, _ value: UILabel) -> UIView {
            let cap = UILabel(); cap.text = caption; cap.font = .systemFont(ofSize: 11, weight: .semibold)
            cap.textColor = UIColor.white.withAlphaComponent(0.5); cap.textAlignment = .center
            value.font = .systemFont(ofSize: 20, weight: .bold); value.textColor = .white
            value.textAlignment = .center; value.text = "0"
            let v = UIStackView(arrangedSubviews: [cap, value]); v.axis = .vertical
            v.backgroundColor = UIColor.white.withAlphaComponent(0.08); v.layoutMargins = .init(top: 6, left: 14, bottom: 6, right: 14)
            v.isLayoutMarginsRelativeArrangement = true; v.layer.cornerRadius = 8; v.layer.masksToBounds = true
            return v
        }
        bestLabel.text = "\(best)"
        let scores = UIStackView(arrangedSubviews: [chip(isVI ? "ĐIỂM" : "SCORE", scoreLabel), chip("BEST", bestLabel)])
        scores.axis = .horizontal; scores.spacing = 10

        let header = UIStackView(arrangedSubviews: [title, UIView(), scores])
        header.axis = .horizontal; header.alignment = .center
        header.translatesAutoresizingMaskIntoConstraints = false

        boardView.translatesAutoresizingMaskIntoConstraints = false
        boardView.isUserInteractionEnabled = true

        statusLabel.textColor = UIColor.white.withAlphaComponent(0.7); statusLabel.textAlignment = .center
        statusLabel.font = .systemFont(ofSize: 15, weight: .semibold)

        let newBtn = makeButton(isVI ? "Ván mới" : "New game", filled: false) { [weak self] in self?.newGame() }

        view.addSubview(header); view.addSubview(boardView); view.addSubview(statusLabel); view.addSubview(newBtn)
        let g = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            header.topAnchor.constraint(equalTo: g.topAnchor, constant: 16),
            header.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 20),
            header.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -52),

            boardView.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: -10),
            boardView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            boardView.leadingAnchor.constraint(equalTo: g.leadingAnchor, constant: 20),
            boardView.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -20),
            boardView.heightAnchor.constraint(equalTo: boardView.widthAnchor),

            statusLabel.topAnchor.constraint(equalTo: boardView.bottomAnchor, constant: 18),
            statusLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),

            newBtn.topAnchor.constraint(equalTo: statusLabel.bottomAnchor, constant: 14),
            newBtn.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        ])
    }

    private func newGame() {
        board = [[Int]](repeating: [Int](repeating: 0, count: 4), count: 4)
        score = 0; won = false; over = false; statusLabel.text = ""
        spawn(); spawn(); boardView.board = board
        emit("game_start", ["mode": "classic"])
    }

    @objc private func swiped(_ g: UISwipeGestureRecognizer) {
        guard !over else { return }
        if move(g.direction) {
            spawn(); boardView.board = board
            if score > best { best = score; bestLabel.text = "\(best)"; UserDefaults.standard.set(best, forKey: "go2048.best") }
            if !won, board.contains(where: { $0.contains(2048) }) {
                won = true; statusLabel.text = isVI ? "🎉 Đạt 2048!" : "🎉 You made 2048!"
                emit("level_complete", ["score": score, "win": true])
            }
            if isGameOver() {
                over = true; statusLabel.text = isVI ? "Hết nước đi — Điểm \(score)" : "Game over — Score \(score)"
                emit("game_over", ["score": score])
            }
        }
    }

    // MARK: - Board logic

    private func mergeLeft(_ line: [Int]) -> (line: [Int], gained: Int) {
        var r = line.filter { $0 != 0 }; var out: [Int] = []; var gained = 0; var i = 0
        while i < r.count {
            if i + 1 < r.count && r[i] == r[i + 1] { let v = r[i] * 2; out.append(v); gained += v; i += 2 }
            else { out.append(r[i]); i += 1 }
        }
        while out.count < 4 { out.append(0) }
        return (out, gained)
    }

    /// Move toward `dir`; returns whether anything changed.
    private func move(_ dir: UISwipeGestureRecognizer.Direction) -> Bool {
        var changed = false
        func apply(_ get: (Int) -> [Int], _ set: (Int, [Int]) -> Void) {
            for k in 0..<4 {
                let original = get(k)
                let reversed = dir == .right || dir == .down
                let input = reversed ? original.reversed().map { $0 } : original
                var (merged, gained) = mergeLeft(input)
                score += gained
                if reversed { merged = merged.reversed().map { $0 } }
                if merged != original { changed = true; set(k, merged) }
            }
        }
        switch dir {
        case .left, .right:
            apply({ self.board[$0] }, { self.board[$0] = $1 })
        case .up, .down:
            apply({ k in (0..<4).map { self.board[$0][k] } },
                  { k, col in for r in 0..<4 { self.board[r][k] = col[r] } })
        default: break
        }
        return changed
    }

    private func spawn() {
        var empties: [(Int, Int)] = []
        for r in 0..<4 { for c in 0..<4 where board[r][c] == 0 { empties.append((r, c)) } }
        guard let (r, c) = empties.randomElement() else { return }
        board[r][c] = Int.random(in: 0..<10) == 0 ? 4 : 2
    }

    private func isGameOver() -> Bool {
        for r in 0..<4 { for c in 0..<4 {
            if board[r][c] == 0 { return false }
            if c + 1 < 4 && board[r][c] == board[r][c + 1] { return false }
            if r + 1 < 4 && board[r][c] == board[r + 1][c] { return false }
        } }
        return true
    }
}

private extension NSLayoutConstraint {
    func withPriority(_ p: UILayoutPriority) -> NSLayoutConstraint { priority = p; return self }
}

/// CoreGraphics rendering of the 4×4 board.
final class Board2048View: UIView {
    var board = [[Int]](repeating: [Int](repeating: 0, count: 4), count: 4) { didSet { setNeedsDisplay() } }
    override init(frame: CGRect) { super.init(frame: frame); backgroundColor = .clear; isOpaque = false; contentMode = .redraw }
    required init?(coder: NSCoder) { fatalError() }

    override func draw(_ rect: CGRect) {
        let pad: CGFloat = 8, n: CGFloat = 4
        let side = min(bounds.width, bounds.height)
        let cell = (side - pad * (n + 1)) / n
        // board background
        UIColor(red: 0x1c/255, green: 0x21/255, blue: 0x28/255, alpha: 1).setFill()
        UIBezierPath(roundedRect: CGRect(x: 0, y: 0, width: side, height: side), cornerRadius: 12).fill()
        for r in 0..<4 { for c in 0..<4 {
            let x = pad + CGFloat(c) * (cell + pad), y = pad + CGFloat(r) * (cell + pad)
            let cellRect = CGRect(x: x, y: y, width: cell, height: cell)
            let v = board[r][c]
            let (bg, fg) = Board2048View.colors(v)
            bg.setFill(); UIBezierPath(roundedRect: cellRect, cornerRadius: 8).fill()
            if v > 0 {
                let s = "\(v)"
                let size: CGFloat = v < 100 ? cell * 0.42 : v < 1000 ? cell * 0.34 : cell * 0.26
                let attrs: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: size, weight: .heavy), .foregroundColor: fg]
                let ns = s as NSString; let tsz = ns.size(withAttributes: attrs)
                ns.draw(at: CGPoint(x: x + (cell - tsz.width)/2, y: y + (cell - tsz.height)/2), withAttributes: attrs)
            }
        } }
    }

    static func colors(_ v: Int) -> (UIColor, UIColor) {
        func h(_ x: UInt32) -> UIColor { UIColor(red: CGFloat((x>>16)&0xff)/255, green: CGFloat((x>>8)&0xff)/255, blue: CGFloat(x&0xff)/255, alpha: 1) }
        let dark = h(0x776e65), white = UIColor.white
        switch v {
        case 0: return (h(0x2a2f3a), white)
        case 2: return (h(0xeee4da), dark)
        case 4: return (h(0xede0c8), dark)
        case 8: return (h(0xf2b179), white)
        case 16: return (h(0xf59563), white)
        case 32: return (h(0xf67c5f), white)
        case 64: return (h(0xf65e3b), white)
        case 128: return (h(0xedcf72), white)
        case 256: return (h(0xedcc61), white)
        case 512: return (h(0xedc850), white)
        case 1024: return (h(0xedc53f), white)
        case 2048: return (h(0xedc22e), white)
        default: return (h(0x3c3a32), white)
        }
    }
}
