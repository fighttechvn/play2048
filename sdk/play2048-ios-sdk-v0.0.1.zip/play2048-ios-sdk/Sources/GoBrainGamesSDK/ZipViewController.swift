import UIKit

/// Zip — draw one path through every cell, passing the numbered cells in order.
final class ZipViewController: BaseGameViewController {
    private let n = 5
    private var clue = [Int: Int]()         // cell idx → order (1..k)
    private var userPath = [Int]()          // cell indices in draw order
    private var solved = false
    private let grid = CellGridView()
    private let info = UILabel()

    override func viewDidLoad() {
        super.viewDidLoad()
        grid.cols = n; grid.rows = n; grid.corner = 8
        grid.cellFill = { [weak self] r, c in
            guard let self = self else { return .clear }
            return self.userPath.contains(r*self.n+c) ? self.accent.withAlphaComponent(0.30) : UIColor.white.withAlphaComponent(0.06)
        }
        grid.cellText = { [weak self] r, c in
            guard let self = self, let o = self.clue[r*self.n+c] else { return nil }
            return ("\(o)", .white)
        }
        grid.gridOverlay = { [weak self] ctx, frame, cell in self?.drawPath(ctx, frame, cell) }
        grid.onDrag = { [weak self] r, c in self?.drag(r, c) }
        let t = gameTitleLabel("Zip")
        let i = infoLabel(); i.text = isVI ? "Kéo 1 đường qua mọi ô, theo thứ tự số" : "Draw one path through every cell, in number order"
        info.text = ""
        layoutPuzzle(title: t, grid: grid, info: i, buttons: [
            makeButton(isVI ? "Xoá" : "Clear", filled: false) { [weak self] in self?.clearPath() },
            makeButton(isVI ? "Ván mới" : "New", filled: false) { [weak self] in self?.newGame() },
        ])
        infoRef = i
        newGame()
    }
    private var infoRef: UILabel?

    private func newGame() {
        solved = false; userPath.removeAll(); clue.removeAll()
        let path = Self.hamiltonian(n) ?? Self.snake(n)
        let k = 5
        for j in 0..<k {
            let pos = j == 0 ? 0 : (j == k-1 ? path.count-1 : path.count * j / (k-1))
            clue[path[pos]] = j+1
        }
        grid.setNeedsDisplay(); emit("game_start")
    }
    private func clearPath() { userPath.removeAll(); solved = false; infoRef?.text = ""; grid.setNeedsDisplay() }

    private func drag(_ r: Int, _ c: Int) {
        guard !solved else { return }
        let idx = r*n+c
        if userPath.isEmpty { if clue[idx] == 1 { userPath = [idx]; grid.setNeedsDisplay() }; return }
        if idx == userPath.last { return }
        if userPath.count >= 2 && idx == userPath[userPath.count-2] { userPath.removeLast(); grid.setNeedsDisplay(); return } // backtrack
        guard !userPath.contains(idx) else { return }
        let last = userPath.last!
        if abs(idx/n - last/n) + abs(idx%n - last%n) == 1 {        // adjacent
            userPath.append(idx); grid.setNeedsDisplay(); checkWin()
        }
    }
    private func checkWin() {
        guard userPath.count == n*n else { return }
        var order = [Int]()
        for idx in userPath { if let o = clue[idx] { order.append(o) } }
        if order == Array(1...order.count) {
            solved = true; infoRef?.text = isVI ? "✓ Hoàn tất!" : "✓ Complete!"; emit("level_complete", ["win": true])
        }
    }

    private func drawPath(_ ctx: CGContext, _ frame: CGRect, _ cell: CGFloat) {
        guard userPath.count >= 2 else { return }
        ctx.setStrokeColor(accent.cgColor); ctx.setLineWidth(max(6, cell*0.16)); ctx.setLineJoin(.round); ctx.setLineCap(.round)
        for (k, idx) in userPath.enumerated() {
            let p = CGPoint(x: frame.minX + (CGFloat(idx%n)+0.5)*cell, y: frame.minY + (CGFloat(idx/n)+0.5)*cell)
            if k == 0 { ctx.move(to: p) } else { ctx.addLine(to: p) }
        }
        ctx.strokePath()
    }

    // MARK: - Path generation
    private static func hamiltonian(_ n: Int) -> [Int]? {
        var best: [Int]? = nil
        var attempts = 0
        while attempts < 40 && best == nil {
            attempts += 1
            var used = [Bool](repeating: false, count: n*n)
            var path = [Int]()
            var steps = 0
            let start = Int.random(in: 0..<n*n)
            func dfs(_ cell: Int) -> Bool {
                steps += 1; if steps > 60000 { return false }
                used[cell] = true; path.append(cell)
                if path.count == n*n { return true }
                let r = cell/n, c = cell%n
                var nb = [(r-1, c), (r+1, c), (r, c-1), (r, c+1)]
                    .filter { $0.0 >= 0 && $0.0 < n && $0.1 >= 0 && $0.1 < n }
                    .map { $0.0*n + $0.1 }.filter { !used[$0] }
                nb.shuffle()
                for x in nb where dfs(x) { return true }
                used[cell] = false; path.removeLast(); return false
            }
            if dfs(start) { best = path }
        }
        return best
    }
    private static func snake(_ n: Int) -> [Int] {
        var p = [Int]()
        for r in 0..<n { let cols = r % 2 == 0 ? Array(0..<n) : Array((0..<n).reversed()); for c in cols { p.append(r*n+c) } }
        return p
    }
}
