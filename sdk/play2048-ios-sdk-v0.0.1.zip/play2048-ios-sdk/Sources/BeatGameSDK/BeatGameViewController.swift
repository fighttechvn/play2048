import UIKit

/// Full-screen native game UI: home (level picker + play + settings), settings
/// (mode + colour themes), end screen, first-run coachmark — all UIKit, hosting
/// the CoreGraphics `BeatGameView`. Created via `BeatGameCoordinator`.
final class BeatGameViewController: UIViewController {

    private let config: BeatGameConfig
    private weak var coordinator: BeatGameCoordinator?
    private let game = BeatGameView()
    private let L: Strings

    private var pick = 1
    private var overlays: [UIView] = []
    private var menu: UIView!, settings: UIView!, endView: UIView!, coach: UIView!
    private var levelLabel: UILabel!, endTitle: UILabel!, endScore: UILabel!
    private var nextButton: UIButton!, againButton: UIButton!
    private var lastWasEndless = false
    private let seenKey = "beat.tutorialSeen"

    init(config: BeatGameConfig, coordinator: BeatGameCoordinator) {
        self.config = config; self.coordinator = coordinator
        self.L = Strings.for(config.locale)
        super.init(nibName: nil, bundle: nil)
        if let t = config.theme { BeatTheme.savedIndex = t }
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) not supported") }

    override var prefersStatusBarHidden: Bool { true }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = BeatTheme.current.bg

        game.levelWord = L.level
        game.tutHint = L.tutTap
        game.translatesAutoresizingMaskIntoConstraints = false
        game.onEvent = { [weak self] name, params in self?.handle(name, params) }
        view.addSubview(game)
        NSLayoutConstraint.activate([
            game.topAnchor.constraint(equalTo: view.topAnchor),
            game.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            game.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            game.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])

        buildMenu(); buildSettings(); buildEnd(); buildCoach()
        addCloseButton()

        if config.showTutorial && UserDefaults.standard.string(forKey: seenKey) == nil {
            show(coach)
        } else {
            show(menu)
        }
    }

    // MARK: - Event handling from the game

    private func handle(_ name: String, _ params: [String: Any]) {
        coordinator?.dispatch(BeatGameEvent(name: name, params: params))
        switch name {
        case "level_complete", "game_over":
            let win = name == "level_complete"
            endTitle.text = win ? L.win : L.over
            endScore.text = "\(params["score"] as? Int ?? 0)"
            let showNext = win && !lastWasEndless && game.level < BeatLevels.count
            nextButton.isHidden = !showNext
            style(againButton, filled: !showNext)
            show(endView)
        default: break
        }
    }

    // MARK: - Actions

    private func play(level: Int, guided: Bool) {
        lastWasEndless = false
        hideOverlays()
        game.startLevel(level, guided: guided)
    }
    private func playEndless() { lastWasEndless = true; hideOverlays(); game.startEndless() }

    // MARK: - Overlays

    private func show(_ v: UIView) {
        hideOverlays()
        v.isHidden = false
        view.bringSubviewToFront(v)
        bringCloseToFront()
        // refresh theme-tinted chrome
        view.backgroundColor = BeatTheme.current.bg
    }
    private func hideOverlays() { overlays.forEach { $0.isHidden = true } }

    private func buildMenu() {
        let (panel, stack) = makePanel()
        let title = bigTitle("BEAT")
        let picker = makePicker()
        let playBtn = makeButton(L.play, filled: true) { [weak self] in self?.play(level: self?.pick ?? 1, guided: false) }
        let setBtn = makeButton("⚙ " + L.settings, filled: false) { [weak self] in self?.refreshSettings(); self?.show(self!.settings) }
        [title, picker, playBtn, setBtn].forEach { stack.addArrangedSubview($0) }
        menu = panel; overlays.append(panel); view.addSubview(panel); pin(panel)
    }

    private func buildSettings() {
        let (panel, stack) = makePanel()
        stack.addArrangedSubview(bigTitle(L.settings, size: 30))
        stack.addArrangedSubview(sectionLabel(L.mode))
        stack.addArrangedSubview(makeButton(L.byLevel, filled: false) { [weak self] in self?.show(self!.menu) })
        stack.addArrangedSubview(makeButton(L.endless, filled: false) { [weak self] in self?.playEndless() })
        stack.addArrangedSubview(sectionLabel(L.theme))
        stack.addArrangedSubview(makeThemeGrid())
        stack.addArrangedSubview(makeButton(L.back, filled: false) { [weak self] in self?.show(self!.menu) })
        settings = panel; overlays.append(panel); view.addSubview(panel); pin(panel)
    }

    private func buildEnd() {
        let (panel, stack) = makePanel()
        endTitle = bigTitle(L.over, size: 30)
        endScore = UILabel(); endScore.font = .systemFont(ofSize: 46, weight: .bold)
        endScore.textColor = .white; endScore.textAlignment = .center; endScore.text = "0"
        let scoreCap = sectionLabel(L.score); scoreCap.textAlignment = .center
        nextButton = makeButton(L.next, filled: true) { [weak self] in guard let s = self else { return }; s.play(level: min(BeatLevels.count, s.game.level + 1), guided: false) }
        againButton = makeButton(L.again, filled: false) { [weak self] in guard let s = self else { return }; s.lastWasEndless ? s.playEndless() : s.play(level: s.game.level, guided: false) }
        let menuBtn = makeButton(L.menu, filled: false) { [weak self] in self?.show(self!.menu) }
        [endTitle, endScore, scoreCap, nextButton, againButton, menuBtn].forEach { stack.addArrangedSubview($0) }
        endView = panel; overlays.append(panel); view.addSubview(panel); pin(panel)
    }

    private func buildCoach() {
        let (panel, stack) = makePanel()
        stack.addArrangedSubview(bigTitle(L.howto, size: 30))
        let body = UILabel(); body.text = L.howtoBody; body.numberOfLines = 0
        body.textColor = UIColor.white.withAlpha(0.7); body.textAlignment = .center
        body.font = .systemFont(ofSize: 15)
        stack.addArrangedSubview(body)
        stack.addArrangedSubview(makeButton(L.start, filled: true) { [weak self] in
            UserDefaults.standard.set("1", forKey: self!.seenKey)
            self?.play(level: 1, guided: true)
        })
        stack.addArrangedSubview(makeButton(L.skip, filled: false) { [weak self] in
            UserDefaults.standard.set("1", forKey: self!.seenKey); self?.show(self!.menu)
        })
        coach = panel; overlays.append(panel); view.addSubview(panel); pin(panel)
    }

    // MARK: - Builders

    private func makePanel() -> (UIView, UIStackView) {
        let panel = UIView(); panel.isHidden = true
        panel.backgroundColor = UIColor.black.withAlpha(0.55)
        panel.translatesAutoresizingMaskIntoConstraints = false
        let stack = UIStackView(); stack.axis = .vertical; stack.spacing = 14; stack.alignment = .center
        stack.translatesAutoresizingMaskIntoConstraints = false
        panel.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.centerYAnchor.constraint(equalTo: panel.centerYAnchor),
            stack.leadingAnchor.constraint(greaterThanOrEqualTo: panel.leadingAnchor, constant: 24),
            stack.trailingAnchor.constraint(lessThanOrEqualTo: panel.trailingAnchor, constant: -24),
            stack.centerXAnchor.constraint(equalTo: panel.centerXAnchor),
            stack.widthAnchor.constraint(lessThanOrEqualToConstant: 340),
        ])
        return (panel, stack)
    }

    private func bigTitle(_ s: String, size: CGFloat = 38) -> UILabel {
        let l = UILabel(); l.text = s; l.font = .systemFont(ofSize: size, weight: .heavy)
        l.textColor = .white; l.textAlignment = .center; return l
    }
    private func sectionLabel(_ s: String) -> UILabel {
        let l = UILabel(); l.text = s.uppercased(); l.font = .systemFont(ofSize: 12, weight: .semibold)
        l.textColor = UIColor.white.withAlpha(0.5); return l
    }

    private func makeButton(_ title: String, filled: Bool, action: @escaping () -> Void) -> UIButton {
        let b = ActionButton(type: .system)
        b.setTitle(title, for: .normal)
        b.titleLabel?.font = .systemFont(ofSize: 17, weight: .semibold)
        b.layer.cornerRadius = 14; b.layer.masksToBounds = true
        b.action = action
        b.addTarget(b, action: #selector(ActionButton.fire), for: .touchUpInside)
        b.translatesAutoresizingMaskIntoConstraints = false
        b.widthAnchor.constraint(equalToConstant: 240).isActive = true
        b.heightAnchor.constraint(equalToConstant: 52).isActive = true
        style(b, filled: filled)
        return b
    }
    private func style(_ b: UIButton, filled: Bool) {
        if filled { b.backgroundColor = BeatTheme.current.accent; b.setTitleColor(.white, for: .normal) }
        else { b.backgroundColor = UIColor.white.withAlpha(0.10); b.setTitleColor(.white, for: .normal) }
    }

    private func makePicker() -> UIView {
        let row = UIStackView(); row.axis = .horizontal; row.spacing = 14; row.alignment = .center
        let prev = squareButton("‹") { [weak self] in self?.setPick((self?.pick ?? 1) - 1) }
        let nextB = squareButton("›") { [weak self] in self?.setPick((self?.pick ?? 1) + 1) }
        levelLabel = UILabel(); levelLabel.font = .systemFont(ofSize: 46, weight: .bold)
        levelLabel.textColor = .white; levelLabel.text = "1"
        [prev, levelLabel, nextB].forEach { row.addArrangedSubview($0) }
        return row
    }
    private func squareButton(_ t: String, action: @escaping () -> Void) -> UIButton {
        let b = ActionButton(type: .system)
        b.setTitle(t, for: .normal); b.setTitleColor(.white, for: .normal)
        b.titleLabel?.font = .systemFont(ofSize: 24)
        b.backgroundColor = UIColor.white.withAlpha(0.10); b.layer.cornerRadius = 12
        b.action = action; b.addTarget(b, action: #selector(ActionButton.fire), for: .touchUpInside)
        b.widthAnchor.constraint(equalToConstant: 46).isActive = true
        b.heightAnchor.constraint(equalToConstant: 46).isActive = true
        return b
    }
    private func setPick(_ n: Int) { pick = min(BeatLevels.count, max(1, n)); levelLabel.text = "\(pick)" }

    private var themeGrid: UIStackView?
    private func makeThemeGrid() -> UIView {
        let col = UIStackView(); col.axis = .vertical; col.spacing = 10
        themeGrid = col
        refreshThemeGrid()
        return col
    }
    private func refreshThemeGrid() {
        guard let col = themeGrid else { return }
        col.arrangedSubviews.forEach { $0.removeFromSuperview() }
        var row: UIStackView?
        for (i, th) in BeatTheme.all.enumerated() {
            if i % 2 == 0 { let r = UIStackView(); r.axis = .horizontal; r.spacing = 10; r.distribution = .fillEqually; col.addArrangedSubview(r); row = r }
            row?.addArrangedSubview(makeSwatch(i, th))
        }
    }
    private func makeSwatch(_ index: Int, _ th: BeatTheme) -> UIView {
        let b = ActionButton(type: .custom)
        b.backgroundColor = th.tile
        b.layer.cornerRadius = 12
        b.layer.borderWidth = index == BeatTheme.savedIndex ? 2 : 0
        b.layer.borderColor = UIColor.white.cgColor
        b.setTitle("  " + th.name, for: .normal); b.setTitleColor(.white, for: .normal)
        b.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
        b.contentHorizontalAlignment = .left
        b.heightAnchor.constraint(equalToConstant: 48).isActive = true
        b.action = { [weak self] in BeatTheme.savedIndex = index; self?.refreshThemeGrid(); self?.view.backgroundColor = th.bg }
        b.addTarget(b, action: #selector(ActionButton.fire), for: .touchUpInside)
        return b
    }
    private func refreshSettings() { refreshThemeGrid() }

    // MARK: - Close

    private var closeBtn: UIButton!
    private func addCloseButton() {
        closeBtn = ActionButton(type: .system)
        closeBtn.setTitle("✕", for: .normal); closeBtn.setTitleColor(.white, for: .normal)
        closeBtn.titleLabel?.font = .systemFont(ofSize: 20, weight: .semibold)
        closeBtn.backgroundColor = UIColor.black.withAlpha(0.35); closeBtn.layer.cornerRadius = 18
        (closeBtn as! ActionButton).action = { [weak self] in self?.dismissGame() }
        closeBtn.addTarget(closeBtn, action: #selector(ActionButton.fire), for: .touchUpInside)
        closeBtn.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(closeBtn)
        let g = view.safeAreaLayoutGuide
        NSLayoutConstraint.activate([
            closeBtn.widthAnchor.constraint(equalToConstant: 36),
            closeBtn.heightAnchor.constraint(equalToConstant: 36),
            closeBtn.topAnchor.constraint(equalTo: g.topAnchor, constant: 8),
            closeBtn.trailingAnchor.constraint(equalTo: g.trailingAnchor, constant: -12),
        ])
    }
    private func bringCloseToFront() { if closeBtn != nil { view.bringSubviewToFront(closeBtn) } }
    private func dismissGame() {
        game.teardown()
        dismiss(animated: true) { [weak coordinator] in coordinator?.notifyClose() }
    }

    private func pin(_ v: UIView) {
        NSLayoutConstraint.activate([
            v.topAnchor.constraint(equalTo: view.topAnchor),
            v.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            v.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            v.trailingAnchor.constraint(equalTo: view.trailingAnchor),
        ])
    }
}

/// UIButton that runs a closure (keeps the builder code terse).
private final class ActionButton: UIButton {
    var action: (() -> Void)?
    @objc func fire() { action?() }
}

/// Localized strings.
struct Strings {
    let play, settings, mode, byLevel, endless, theme, next, again, menu, back, win, over, score, level, howto, howtoBody, start, skip, tutTap: String
    static func `for`(_ locale: String) -> Strings {
        locale.hasPrefix("vi")
        ? Strings(play: "Chơi", settings: "Cài đặt", mode: "Chế độ chơi", byLevel: "Theo màn", endless: "Vô tận",
                  theme: "Màu sắc", next: "Màn tiếp", again: "Chơi lại", menu: "Menu", back: "Quay lại",
                  win: "Hoàn thành!", over: "Kết thúc", score: "ĐIỂM", level: "MÀN",
                  howto: "Cách chơi", howtoBody: "Các ô đen rơi xuống theo 4 cột. Ô ngắn thì chạm; ô dài thì nhấn giữ. Chạm khi ô tới vạch dưới cùng. Lượt tập sẽ chờ bạn.",
                  start: "Tập chơi", skip: "Bỏ qua", tutTap: "👇 Chạm ô đang sáng")
        : Strings(play: "Play", settings: "Settings", mode: "Play mode", byLevel: "By level", endless: "Endless",
                  theme: "Theme", next: "Next level", again: "Play again", menu: "Menu", back: "Back",
                  win: "Level clear!", over: "Game over", score: "SCORE", level: "LEVEL",
                  howto: "How to play", howtoBody: "Black tiles fall down 4 lanes. Tap short tiles; press & hold the long ones. Tap when a tile reaches the bottom line. The practice round waits for you.",
                  start: "Start", skip: "Skip", tutTap: "👇 Tap the glowing tile")
    }
}
