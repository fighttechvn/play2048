//  BeatGame.swift
//  BeatGameSDK — embed the GoBrain "Beat" music game in any iOS app.
//
//  Usage:
//    let beat = BeatGameCoordinator(config: .init(locale: "vi"))
//    beat.onEvent = { print($0.name, $0.params) }
//    beat.onGameOver = { print("score", $0.score ?? 0) }
//    beat.present(from: self)
//
//  The game is a self-contained H5 bundle shipped inside this package and run in
//  a WKWebView; gameplay events (play / next level / end game / score …) are
//  forwarded to your app as `BeatGameEvent`s.

import UIKit

/// Options for a game session.
public struct BeatGameConfig {
    /// UI language, e.g. "en" or "vi".
    public var locale: String
    /// Show the first-run guided tutorial (level 1) on first launch.
    public var showTutorial: Bool
    /// Optional initial colour theme index (0…5). `nil` keeps the player's choice.
    public var theme: Int?

    public init(locale: String = "en", showTutorial: Bool = true, theme: Int? = nil) {
        self.locale = locale
        self.showTutorial = showTutorial
        self.theme = theme
    }
}

/// A gameplay event emitted by the game. `name` is the raw event id; typed
/// accessors expose the common fields.
public struct BeatGameEvent {
    /// Raw event name: `game_start`, `level_complete`, `game_over`, …
    public let name: String
    /// Raw parameters payload.
    public let params: [String: Any]

    public init(name: String, params: [String: Any]) {
        self.name = name
        self.params = params
    }

    /// Semantic kind of the event.
    public enum Kind: String {
        case gameStart = "game_start"
        case levelComplete = "level_complete"
        case gameOver = "game_over"
        case unknown
    }
    public var kind: Kind { Kind(rawValue: name) ?? .unknown }

    public var level: Int? { params["level"] as? Int }
    public var score: Int? { params["score"] as? Int }
    public var mode: String? { params["mode"] as? String }            // "level" | "endless" | "tutorial" | "track"
    public var durationMs: Int? { params["duration_ms"] as? Int }
    public var accuracy: Int? { params["accuracy"] as? Int }
}

/// Delegate alternative to the closure callbacks.
public protocol BeatGameDelegate: AnyObject {
    func beatGame(_ coordinator: BeatGameCoordinator, didEmit event: BeatGameEvent)
    func beatGameDidClose(_ coordinator: BeatGameCoordinator)
}
public extension BeatGameDelegate {
    func beatGameDidClose(_ coordinator: BeatGameCoordinator) {}
}

/// Opens the game and relays its events. Hold a strong reference while playing.
public final class BeatGameCoordinator {

    public let config: BeatGameConfig
    public weak var delegate: BeatGameDelegate?

    /// Fires for every event.
    public var onEvent: ((BeatGameEvent) -> Void)?
    /// Convenience callbacks for the common events.
    public var onGameStart: ((BeatGameEvent) -> Void)?
    public var onLevelComplete: ((BeatGameEvent) -> Void)?
    public var onGameOver: ((BeatGameEvent) -> Void)?
    /// Fires when the game screen is closed by the user.
    public var onClose: (() -> Void)?

    public init(config: BeatGameConfig = BeatGameConfig()) {
        self.config = config
    }

    /// Build the game view controller (full-screen) without presenting it.
    public func makeViewController() -> UIViewController {
        BeatGameViewController(config: config, coordinator: self)
    }

    /// Present the game full-screen from `presenter`.
    @discardableResult
    public func present(from presenter: UIViewController, animated: Bool = true) -> UIViewController {
        let vc = makeViewController()
        vc.modalPresentationStyle = .fullScreen
        presenter.present(vc, animated: animated)
        return vc
    }

    // MARK: internal dispatch (called by the view controller)
    func dispatch(_ event: BeatGameEvent) {
        onEvent?(event)
        delegate?.beatGame(self, didEmit: event)
        switch event.kind {
        case .gameStart: onGameStart?(event)
        case .levelComplete: onLevelComplete?(event)
        case .gameOver: onGameOver?(event)
        case .unknown: break
        }
    }
    func notifyClose() {
        onClose?()
        delegate?.beatGameDidClose(self)
    }
}
