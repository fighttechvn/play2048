import AVFoundation

/// Synthesizes the game's notes natively (no audio files). Pre-renders a short
/// PCM buffer per scale degree and plays them through a small pool of player
/// nodes so rapid notes overlap instead of queueing.
final class BeatAudio {
    private let engine = AVAudioEngine()
    private var voices: [AVAudioPlayerNode] = []
    private var nextVoice = 0
    private let sr = 44_100.0
    private var notes: [AVAudioPCMBuffer] = []
    private var thud: AVAudioPCMBuffer?
    private var started = false

    // C-major-ish pool (matches the web game's FREQ).
    private let freqs: [Double] = [261.63, 293.66, 329.63, 349.23, 392.00, 440.00, 493.88, 523.25]

    init() {
        guard let fmt = AVAudioFormat(standardFormatWithSampleRate: sr, channels: 1) else { return }
        notes = freqs.map { makeNote(freq: $0, fmt: fmt) }
        thud = makeThud(fmt: fmt)
        for _ in 0..<8 {
            let p = AVAudioPlayerNode()
            engine.attach(p)
            engine.connect(p, to: engine.mainMixerNode, format: fmt)
            voices.append(p)
        }
    }

    /// Call from a user gesture (audio session + engine start).
    func start() {
        guard !started else { return }
        do {
            try AVAudioSession.sharedInstance().setCategory(.ambient, mode: .default, options: [.mixWithOthers])
            try AVAudioSession.sharedInstance().setActive(true)
            try engine.start()
            voices.forEach { $0.play() }
            started = true
        } catch { /* silent — game still playable */ }
    }

    func stop() {
        guard started else { return }
        voices.forEach { $0.stop() }
        engine.stop()
        started = false
        try? AVAudioSession.sharedInstance().setActive(false, options: [.notifyOthersOnDeactivation])
    }

    func note(_ deg: Int) {
        guard started, !notes.isEmpty else { return }
        let buf = notes[((deg % notes.count) + notes.count) % notes.count]
        play(buf)
    }
    func miss() { if let t = thud { play(t) } }

    private func play(_ buf: AVAudioPCMBuffer) {
        guard started else { return }
        let v = voices[nextVoice]; nextVoice = (nextVoice + 1) % voices.count
        v.scheduleBuffer(buf, at: nil, options: .interrupts, completionHandler: nil)
    }

    // MARK: - Synthesis

    private func makeNote(freq: Double, fmt: AVAudioFormat) -> AVAudioPCMBuffer {
        let dur = 0.6, n = AVAudioFrameCount(sr * dur)
        let buf = AVAudioPCMBuffer(pcmFormat: fmt, frameCapacity: n)!
        buf.frameLength = n
        let p = buf.floatChannelData![0]
        for i in 0..<Int(n) {
            let t = Double(i) / sr
            let attack = 0.01
            let env = t < attack ? t / attack : max(0, exp(-(t - attack) * 4.5))
            let s = sin(2 * .pi * freq * t) + 0.35 * sin(2 * .pi * freq * 2 * t)
            p[i] = Float(s * env * 0.22)
        }
        return buf
    }

    private func makeThud(fmt: AVAudioFormat) -> AVAudioPCMBuffer {
        let dur = 0.22, n = AVAudioFrameCount(sr * dur)
        let buf = AVAudioPCMBuffer(pcmFormat: fmt, frameCapacity: n)!
        buf.frameLength = n
        let p = buf.floatChannelData![0]
        for i in 0..<Int(n) {
            let t = Double(i) / sr
            let f = 180.0 * exp(-t * 6)
            p[i] = Float(sin(2 * .pi * f * t) * exp(-t * 9) * 0.3)
        }
        return buf
    }
}
