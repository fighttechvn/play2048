import UIKit

/// A youthful colour palette for the game. Mirrors the web game's themes.
struct BeatTheme {
    let name: String
    let bg: UIColor
    let fg: UIColor
    let accent: UIColor
    let tile: UIColor
    let tileActive: UIColor
    let miss: UIColor

    static let all: [BeatTheme] = [
        BeatTheme(name: "Violet",    bg: hex(0x0e1116), fg: hex(0xf4f6fb), accent: hex(0x7c5cff), tile: hex(0x161d29), tileActive: hex(0x262f44), miss: hex(0xff5470)),
        BeatTheme(name: "Sunset",    bg: hex(0x1b1020), fg: hex(0xfdeef2), accent: hex(0xff7a8a), tile: hex(0x2a1626), tileActive: hex(0x3c2238), miss: hex(0xff5470)),
        BeatTheme(name: "Ocean",     bg: hex(0x07131b), fg: hex(0xeafaff), accent: hex(0x2dd4bf), tile: hex(0x0f2630), tileActive: hex(0x163945), miss: hex(0xff6b6b)),
        BeatTheme(name: "Lime",      bg: hex(0x0c1410), fg: hex(0xf0ffe9), accent: hex(0xa3e635), tile: hex(0x16230f), tileActive: hex(0x21351a), miss: hex(0xfb7185)),
        BeatTheme(name: "Mango",     bg: hex(0x1a1206), fg: hex(0xfff6e6), accent: hex(0xfbbf24), tile: hex(0x2a1e0c), tileActive: hex(0x3c2c12), miss: hex(0xf87171)),
        BeatTheme(name: "Bubblegum", bg: hex(0x14101c), fg: hex(0xfbeeff), accent: hex(0xc084fc), tile: hex(0x20182c), tileActive: hex(0x2e2440), miss: hex(0xfb7185)),
    ]

    static func hex(_ v: UInt32) -> UIColor {
        UIColor(red: CGFloat((v >> 16) & 0xff) / 255,
                green: CGFloat((v >> 8) & 0xff) / 255,
                blue: CGFloat(v & 0xff) / 255, alpha: 1)
    }

    private static let key = "beat.theme"
    static var savedIndex: Int {
        get { min(all.count - 1, max(0, UserDefaults.standard.integer(forKey: key))) }
        set { UserDefaults.standard.set(newValue, forKey: key) }
    }
    static var current: BeatTheme { all[savedIndex] }
}

extension UIColor {
    func withAlpha(_ a: CGFloat) -> UIColor { withAlphaComponent(a) }
}
