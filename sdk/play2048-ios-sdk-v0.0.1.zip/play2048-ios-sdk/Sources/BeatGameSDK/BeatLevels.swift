import Foundation

/// One tile: a lane, a scale-degree note, and a unit-length (1 = tap, ≥2 = hold).
struct BeatTile {
    let lane: Int
    let deg: Int
    let units: Int
}

/// Deterministic level generator — a Swift port of the web game's `gen-levels.mjs`
/// (difficulty curve + long-tile probability), so the native SDK ships no data
/// files. `level` is 1-based.
enum BeatLevels {
    static let count = 60
    private static let lanes = 4

    // public-domain folk/classical melodies as scale-degree indices
    private static let bank: [[Int]] = [
        [0,0,4,4,5,5,4,3,3,2,2,1,1,0],   // Twinkle Twinkle
        [2,1,0,1,2,2,2,1,1,1,2,4,4],     // Mary Had a Little Lamb
        [2,2,3,4,4,3,2,1,0,0,1,2,2,1,1], // Ode to Joy
        [0,0,0,1,2,2,1,2,3,4],           // Row Row Row Your Boat
        [4,5,4,3,2,3,4,1,2,3,2,3,4],     // London Bridge
    ]

    private static func lerp(_ a: Double, _ b: Double, _ t: Double) -> Double { a + (b - a) * t }
    private static func easeInOut(_ t: Double) -> Double { t < 0.5 ? 2*t*t : 1 - pow(-2*t + 2, 2)/2 }

    struct Params { let bpm: Int; let repeats: Int; let longProb: Double; let maxUnits: Int }

    /// The difficulty curve. Mirrors the JS `paramsForLevel(i, N)` (0-based i).
    static func params(_ i: Int) -> Params {
        let t0 = Double(i) / Double(count - 1)
        let saw = Double(i % 6) / 6.0
        let t = max(0, min(1, easeInOut(t0) - 0.16 * saw))
        let longProb = t > 0.12 ? lerp(0, 0.3, (t - 0.12) / 0.88) : 0
        return Params(
            bpm: Int((lerp(70, 200, t)).rounded()),
            repeats: 1 + Int(lerp(0, 3, t)),
            longProb: longProb,
            maxUnits: t > 0.55 ? 3 : 2
        )
    }

    /// Build the tiles for a 1-based level.
    static func tiles(level: Int) -> (bpm: Int, tiles: [BeatTile]) {
        let i = max(0, min(count - 1, level - 1))
        let p = params(i)
        var rng = LCG(seed: UInt32(1000 + i))
        let melody = bank[i % bank.count]
        var out: [BeatTile] = []
        var prevLane = -1
        for _ in 0..<p.repeats {
            for deg in melody {
                var lane = Int(rng.next() * Double(lanes))
                if lane == prevLane { lane = (lane + 1) % lanes }
                let units = rng.next() < p.longProb ? 2 + Int(rng.next() * Double(p.maxUnits - 1)) : 1
                out.append(BeatTile(lane: lane, deg: deg, units: units))
                prevLane = lane
            }
        }
        return (p.bpm, out)
    }
}

/// Tiny linear-congruential RNG (matches the JS generator for reproducibility).
private struct LCG {
    private var s: UInt32
    init(seed: UInt32) { s = seed }
    mutating func next() -> Double {
        s = s &* 1664525 &+ 1013904223
        return Double(s) / 4294967296.0
    }
}
