import UIKit

/// The gameplay surface — falling tiles rendered with CoreGraphics, driven by a
/// CADisplayLink, with tap + long-press input. A native port of the web engine:
/// top-half lead-in, hit zone, long (hold) tiles, danger bar, forgiving tutorial.
final class BeatGameView: UIView {

    var onEvent: ((String, [String: Any]) -> Void)?
    var levelWord = "LEVEL"
    var tutHint = "👇 Tap the glowing tile"

    private let lanes = 4
    private let leadFrac: CGFloat = 0.55

    private struct RTile { let lane: Int; let deg: Int; let units: Int; var done = false; var h: CGFloat = 0; var off: CGFloat = 0 }
    private var tiles: [RTile] = []
    private var cursor = 0
    private var scroll: CGFloat = 0
    private var speed: CGFloat = 0
    private(set) var score = 0
    private var combo = 0
    private var danger: CGFloat = 0
    private var flash: CGFloat = 0
    private var holdLane = -1
    private var holding = false
    private(set) var alive = false
    private var tutorial = false
    private var endless = false
    private(set) var level = 1
    private var best = 0
    private var lastT: CFTimeInterval = 0
    private var link: CADisplayLink?
    private let audio = BeatAudio()

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        isMultipleTouchEnabled = false
        contentMode = .redraw
        isOpaque = false
    }
    required init?(coder: NSCoder) { fatalError("init(coder:) not supported") }

    private var W: CGFloat { bounds.width }
    private var H: CGFloat { bounds.height }
    private var laneW: CGFloat { W / CGFloat(lanes) }
    private var rowH: CGFloat { H / 4 }

    // MARK: - Start / stop

    private var pendingBPM = 100
    private var needsLaunch = false

    func startLevel(_ n: Int, guided: Bool) {
        endless = false; level = max(1, n); tutorial = guided
        let built = BeatLevels.tiles(level: level)
        tiles = built.tiles.map { RTile(lane: $0.lane, deg: $0.deg, units: $0.units) }
        pendingBPM = built.bpm
        resetState()
        onEvent?("game_start", guided ? ["mode": "tutorial"] : ["mode": "level", "level": level])
        armLaunch()
    }

    func startEndless() {
        endless = true; tutorial = false; level = 1
        tiles = (0..<6).map { _ in randTile() }
        pendingBPM = 95
        resetState()
        onEvent?("game_start", ["mode": "endless"])
        armLaunch()
    }

    private func resetState() {
        score = 0; combo = 0; cursor = 0; flash = 0; danger = 0
        holdLane = -1; holding = false; alive = true
        best = UserDefaults.standard.integer(forKey: "beat.best")
    }

    /// Begin now if laid out, else defer to `layoutSubviews` — tile geometry needs
    /// the real bounds, not a pre-layout zero frame.
    private func armLaunch() {
        if bounds.height > 1 { beginNow() } else { needsLaunch = true }
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        if needsLaunch && bounds.height > 1 { needsLaunch = false; beginNow() }
    }

    private func beginNow() {
        speed = bpmToSpeed(pendingBPM)
        prep(); scroll = -H * leadFrac
        audio.start()
        lastT = CACurrentMediaTime()
        setNeedsDisplay()
        link?.invalidate()
        let l = CADisplayLink(target: self, selector: #selector(step(_:)))
        l.add(to: .main, forMode: .common)
        link = l
    }

    func teardown() { link?.invalidate(); link = nil; alive = false; audio.stop() }
    func pause() { link?.isPaused = true }
    func resume() { if link != nil { link?.isPaused = false; lastT = CACurrentMediaTime() } }

    private func bpmToSpeed(_ bpm: Int) -> CGFloat { rowH * CGFloat(bpm) / 60 }
    private func randTile() -> RTile { RTile(lane: Int.random(in: 0..<lanes), deg: [0,1,2,4,5].randomElement()!, units: 1) }

    private func prep() {
        var o: CGFloat = 0
        for i in tiles.indices {
            tiles[i].h = CGFloat(max(1, tiles[i].units)) * rowH
            tiles[i].off = o; tiles[i].done = false
            o += tiles[i].h
        }
    }

    private func tileBottom(_ i: Int) -> CGFloat { i < tiles.count ? H - tiles[i].off + scroll : 0 }
    private func tileTop(_ i: Int) -> CGFloat { i < tiles.count ? tileBottom(i) - tiles[i].h : 0 }

    // MARK: - Loop

    @objc private func step(_ link: CADisplayLink) {
        var dt = link.timestamp - lastT; lastT = link.timestamp
        if dt > 0.05 { dt = 0.05 }
        if dt <= 0 { return }
        tick(CGFloat(dt))
        if alive { setNeedsDisplay() }
    }

    private func tick(_ dt: CGFloat) {
        guard alive else { return }
        if endless { speed += 1.5 * dt }
        scroll += speed * dt
        if flash > 0 { flash -= dt }
        guard cursor < tiles.count else { return }
        if tutorial {
            let b = tileBottom(cursor); if b > H { scroll -= (b - H) }   // wait for the tap
        } else {
            let cur = tiles[cursor]
            if holding && cur.units >= 2 && holdLane == cur.lane {
                danger = 0
                if tileTop(cursor) >= H - rowH * 0.5 { clearTile() }      // long tile fully held
            } else {
                let trigger = H - rowH * 0.4, dead = H + rowH * 0.6
                danger = max(0, min(1, (tileBottom(cursor) - trigger) / (dead - trigger)))
                if tileBottom(cursor) > dead { miss() }
            }
        }
    }

    // MARK: - Input

    private func laneAt(_ x: CGFloat) -> Int { min(lanes - 1, max(0, Int(x / laneW))) }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard alive, let t = touches.first else { return }
        audio.start()
        tap(laneAt(t.location(in: self).x))
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) { up() }
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) { up() }

    private func tap(_ lane: Int) {
        guard alive, cursor < tiles.count else { return }
        holdLane = lane
        let cur = tiles[cursor]
        if cur.lane != lane { miss(); return }
        if tileBottom(cursor) < H - rowH * 1.2 { return }   // too early — forgive
        if cur.units >= 2 { holding = true } else { clearTile() }
    }
    private func up() { if holding { holding = false; if !tutorial { miss() } }; holdLane = -1 }

    private func clearTile() {
        let cur = tiles[cursor]
        audio.note(cur.deg)
        tiles[cursor].done = true; cursor += 1; score += 1; combo += 1; holding = false; danger = 0
        if endless { tiles.append(randTile()); fixupLast(); speed += 0.6; return }
        if cursor >= tiles.count { if tutorial { tutorial = false }; endGame(win: true) }
    }
    private func fixupLast() {
        let i = tiles.count - 1
        let prevEnd = i > 0 ? tiles[i - 1].off + tiles[i - 1].h : 0
        tiles[i].h = rowH; tiles[i].off = prevEnd; tiles[i].done = false
    }
    private func miss() {
        audio.miss(); combo = 0; flash = 0.25; holding = false
        if !tutorial { endGame(win: false) }
    }
    private func endGame(win: Bool) {
        alive = false; link?.invalidate(); link = nil
        if score > best { best = score; UserDefaults.standard.set(best, forKey: "beat.best") }
        setNeedsDisplay()
        onEvent?(win ? "level_complete" : "game_over",
                 ["score": score, "level": level, "mode": endless ? "endless" : "level"])
    }

    // MARK: - Draw

    override func draw(_ rect: CGRect) {
        guard let ctx = UIGraphicsGetCurrentContext() else { return }
        let th = BeatTheme.current
        let aAccent = th.accent, aMiss = th.miss

        ctx.setFillColor(th.bg.cgColor); ctx.fill(bounds)

        // lane separators
        ctx.setStrokeColor(UIColor.white.withAlpha(0.05).cgColor); ctx.setLineWidth(1)
        for l in 1..<lanes { ctx.move(to: CGPoint(x: CGFloat(l) * laneW, y: 0)); ctx.addLine(to: CGPoint(x: CGFloat(l) * laneW, y: H)) }
        ctx.strokePath()

        // tiles (from the active one upward)
        var i = cursor
        while i < tiles.count {
            let top = tileTop(i); if top > H { break }
            let t = tiles[i]
            if !t.done && top + t.h >= -rowH {
                let x = CGFloat(t.lane) * laneW
                let r = CGRect(x: x + 5, y: top + 4, width: laneW - 10, height: t.h - 8)
                let path = UIBezierPath(roundedRect: r, cornerRadius: 12)
                (i == cursor ? th.tileActive : th.tile).setFill(); path.fill()
                if i == cursor { aAccent.withAlpha(0.18).setFill(); path.fill() }
                if t.units >= 2 {   // hold pill
                    UIColor.white.withAlpha(0.12).setFill()
                    UIBezierPath(roundedRect: CGRect(x: x + laneW/2 - 4, y: top + 12, width: 8, height: t.h - 24), cornerRadius: 4).fill()
                }
            }
            i += 1
        }

        // Nothing more to draw on the idle menu (no level loaded yet).
        if tiles.isEmpty { return }

        // hit-line band (accent; red flash on miss)
        (flash > 0 ? aMiss.withAlpha(0.5) : aAccent.withAlpha(0.10)).setFill()
        ctx.fill(CGRect(x: 0, y: H - rowH, width: W, height: rowH))

        // danger progress bar (pale → deep)
        if danger > 0 && !tutorial {
            aMiss.withAlpha(0.12 + 0.5 * danger).setFill()
            ctx.fill(CGRect(x: 0, y: H - rowH, width: W, height: rowH))
            let bh = max(6, rowH * 0.10)
            aAccent.withAlpha(0.22).setFill(); ctx.fill(CGRect(x: 0, y: H - bh, width: W, height: bh))
            aMiss.withAlpha(0.45 + 0.55 * danger).setFill(); ctx.fill(CGRect(x: 0, y: H - bh, width: W * danger, height: bh))
        }

        // tutorial: pulsing ring on the cursor tile + hint
        if tutorial, cursor < tiles.count {
            let cx = CGFloat(tiles[cursor].lane) * laneW + laneW/2, cy = H - rowH/2
            let p = 0.5 + 0.5 * sin(CACurrentMediaTime() / 0.18)
            ctx.setStrokeColor(aAccent.withAlpha(0.5 + 0.4 * CGFloat(p)).cgColor); ctx.setLineWidth(3)
            ctx.addArc(center: CGPoint(x: cx, y: cy), radius: 24 + 8 * CGFloat(p), startAngle: 0, endAngle: .pi*2, clockwise: false)
            ctx.strokePath()
            drawText(tutHint, center: CGPoint(x: W/2, y: H*0.18), size: 15, color: th.fg, bg: aAccent.withAlpha(0.92))
        }

        // HUD
        let top = safeAreaInsets.top + 16
        let left = endless ? "★ \(best)" : "\(levelWord) \(level)"
        let right = score > 0 && combo > 2 ? "\(score)  ×\(combo)" : "\(score)"
        drawText(left, at: CGPoint(x: 16, y: top), size: 15, color: th.fg, align: .left)
        drawText(right, at: CGPoint(x: W - 16, y: top), size: 15, color: th.fg, align: .right)
    }

    private func drawText(_ s: String, at p: CGPoint, size: CGFloat, color: UIColor, align: NSTextAlignment) {
        let para = NSMutableParagraphStyle(); para.alignment = align
        let attrs: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: size, weight: .semibold), .foregroundColor: color, .paragraphStyle: para]
        let ns = s as NSString
        let bound = ns.size(withAttributes: attrs)
        let x = align == .right ? p.x - bound.width : p.x
        ns.draw(at: CGPoint(x: x, y: p.y), withAttributes: attrs)
    }
    private func drawText(_ s: String, center: CGPoint, size: CGFloat, color: UIColor, bg: UIColor) {
        let attrs: [NSAttributedString.Key: Any] = [.font: UIFont.systemFont(ofSize: size, weight: .semibold), .foregroundColor: color]
        let ns = s as NSString
        let sz = ns.size(withAttributes: attrs)
        let pad: CGFloat = 12
        let rect = CGRect(x: center.x - sz.width/2 - pad, y: center.y - sz.height/2 - 6, width: sz.width + pad*2, height: sz.height + 12)
        bg.setFill(); UIBezierPath(roundedRect: rect, cornerRadius: rect.height/2).fill()
        ns.draw(at: CGPoint(x: center.x - sz.width/2, y: center.y - sz.height/2), withAttributes: attrs)
    }
}
