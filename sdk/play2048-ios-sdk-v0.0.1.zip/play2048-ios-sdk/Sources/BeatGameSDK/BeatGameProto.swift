//  BeatGameProto.swift
//  Bridges the SDK's Swift-friendly types to the shared Protobuf entities
//  (generated from proto/gobrain/beat/v1/beat.proto via `npm run proto`).
//  The same .proto generates the TypeScript/JS types for the web app + server,
//  so the event/level/config contract is single-source-of-truth across platforms.

import Foundation

public extension BeatGameEvent {
    /// This event as the shared Protobuf message (serialize / forward to a backend).
    var proto: Gobrain_Beat_V1_GameEvent {
        var e = Gobrain_Beat_V1_GameEvent()
        switch kind {
        case .gameStart: e.name = .eventGameStart
        case .levelComplete: e.name = .eventLevelComplete
        case .gameOver: e.name = .eventGameOver
        case .unknown: e.name = .unspecified
        }
        e.gameID = params["game_id"] as? String ?? "beat"
        e.mode = BeatGameEvent.protoMode(mode)
        e.level = Int32(level ?? 0)
        e.score = Int32(score ?? 0)
        e.durationMs = Int32(durationMs ?? 0)
        e.accuracy = Int32(accuracy ?? 0)
        e.maxCombo = Int32(params["maxCombo"] as? Int ?? 0)
        return e
    }

    /// Protobuf binary wire-format of this event.
    func serializedProto() -> Data { (try? proto.serializedData()) ?? Data() }

    private static func protoMode(_ m: String?) -> Gobrain_Beat_V1_PlayMode {
        switch m {
        case "level": return .level
        case "endless": return .endless
        case "tutorial": return .tutorial
        case "track": return .track
        default: return .unspecified
        }
    }
}

public extension BeatGameConfig {
    /// This config as the shared Protobuf message.
    var proto: Gobrain_Beat_V1_GameConfig {
        var c = Gobrain_Beat_V1_GameConfig()
        c.locale = locale
        c.showTutorial = showTutorial
        if let t = theme { c.theme = Int32(t) }
        return c
    }
}
