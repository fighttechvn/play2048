# Play2048 — iOS Game SDK (v0.0.1)

Native Swift mini-game SDKs (no WebView, no HTML/CSS/JS) to embed GoBrain games in any iOS app.
One Swift Package, two products:

- **GoBrainGamesSDK** — 2048, Sudoku, Tango, Patch (Shikaku), Zip, Wend, Mend.
- **BeatGameSDK** — the Beat music/tiles game (level + endless + tutorial + 6 themes) + shared Protobuf entities.

iOS 12+ · UIKit · CoreGraphics + AVAudioEngine. Depends on `apple/swift-protobuf`.

## Setup

1. Unzip into your project, e.g. `YourApp/Packages/Play2048/`.
2. Add it as a **local Swift package**:
   - **Xcode:** *File → Add Package Dependencies… → Add Local…* → pick the `Play2048` folder, then add the `GoBrainGamesSDK` and/or `BeatGameSDK` products to your app target.
   - **XcodeGen (`project.yml`):**
     ```yaml
     packages:
       Play2048:
         path: Packages/Play2048
     targets:
       YourApp:
         dependencies:
           - package: Play2048
             product: GoBrainGamesSDK
           - package: Play2048
             product: BeatGameSDK
     ```
3. Build for the iOS Simulator to verify (SwiftProtobuf resolves automatically).

## Usage

```swift
import GoBrainGamesSDK

let games = GoBrainGamesCoordinator(config: .init(locale: "vi"))
games.onEvent = { e in print(e.gameId, e.name, e.score ?? -1) }
games.present(.sudoku, from: self)   // .go2048 .tango .patch .zip .wend .mend
```

```swift
import BeatGameSDK

let beat = BeatGameCoordinator(config: .init(locale: "vi", showTutorial: true))
beat.onGameOver = { print("score", $0.score ?? 0) }
beat.present(from: self)
```

Each game is full-screen, generates its own levels, has a close button, and emits
`game_start` / `level_complete` / `game_over` events (with `score`, `level`, `mode`).

## Shared entities (Protobuf)

`proto/gobrain/beat/v1/beat.proto` is the single source of truth for game entities
(`GameEvent`, levels, packs, config) shared across the web app (TS/JS) and this iOS SDK.
