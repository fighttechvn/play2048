// swift-tools-version:5.5
import PackageDescription

let package = Package(
    name: "Play2048",
    defaultLocalization: "en",
    platforms: [.iOS(.v12)],
    products: [
        .library(name: "BeatGameSDK", targets: ["BeatGameSDK"]),
        .library(name: "GoBrainGamesSDK", targets: ["GoBrainGamesSDK"]),
    ],
    dependencies: [
        .package(url: "https://github.com/apple/swift-protobuf.git", from: "1.28.0"),
    ],
    targets: [
        // Beat music game (native Swift) + shared Protobuf entities.
        .target(
            name: "BeatGameSDK",
            dependencies: [.product(name: "SwiftProtobuf", package: "swift-protobuf")],
            path: "Sources/BeatGameSDK"
        ),
        // GoBrain puzzle games (2048, sudoku, tango, patch, zip, wend, mend) — native Swift.
        .target(name: "GoBrainGamesSDK", path: "Sources/GoBrainGamesSDK"),
    ]
)
